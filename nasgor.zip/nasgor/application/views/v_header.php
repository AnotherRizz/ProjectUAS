<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nasgor Bangor </title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Carter+One&family=Open+Sans:ital,wght@0,500;0,700;1,400&family=Poppins:wght@600;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php
     echo base_url() ?>assets/css/stylebuku.css">
</head>
<body>
    <div id="wrapper">
        <header class=" bg-warning">
            <hgroup >
                <h1 style="font-weight: 800; ">Nasgor <span style="color: #808080;">Bangor.</span></h1>
                <h5 style="font-weight:600; color:#2f4f4f;"> Karna Rasa Ga pernah Bohong!!</h5>
            </hgroup>
            <nav>
                <ul >
                    <li style="color: #2f4f4f; font-weight:600; "><a href="<?php echo base_url().'index.php/web'?>">Home</a></li>
                    <li style="color: #2f4f4f; font-weight:600;"><a href="<?php echo base_url().'index.php/web/about'?>">Pemesanan</a></li>
                </ul>
            </nav>
            <div class="clear"></div>
        </header>


  
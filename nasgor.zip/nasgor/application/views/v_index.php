<section class="bg-dark">
    
   
<div class="container text-center">
  <div class="row">
    <div class="col">
    <div class="card" style="width: 18rem;">
  <img src="../assets/nasgor1.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Nasgor Special Bgt</h5>
    <p class="card-text">Rp.20.000</p>
    <a href="#" class="btn btn-primary">Pesan Sekarang</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 18rem;">
  <img src="../assets/nasgor2.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Nasgor Seafood Fresh</h5>
    <p class="card-text">Rp.25.000</p>
    <a href="#" class="btn btn-primary">Pesan Sekarang</a>
  </div>
</div>
    </div>
    <div class="col">
    <div class="card" style="width: 18rem;">
  <img src="../assets/nasgor3.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Nasgor Kambing Asli</h5>
    <p class="card-text">Rp.30.000</p>
    <a href="#" class="btn btn-primary">Pesan Sekarang</a>
  </div>
</div>
    </div>
  </div>
</div>

</section>

    <section>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form input Matakuliah</title>
</head>
<body>
    <center>
        <form action="<?= base_url('matakuliah/cetak');?>" 
        method="post">
                <table>
                    <tr>
                        <th colspan="3">
                            Halaman Pemesanan
                        </th>
                    </tr>
                    <tr>
                        <td colspan="3">
                         <hr>
                        </td>
                    </tr>
                    <tr>
                        <th>Nama Pembeli</th>
                        <th>:</th>
                        <td>
                        <input type="text" name="kode" id="kode">
                        </td>
                    </tr>
                    <tr>
                       <th>Pilihan Menu</th>
                       <td>:</td>
                       <td>
                          <select name="sks" id="sks">
                             <option value="">Pilih Menu</option>
                             <option value="2">Nasgor Special Bgt</option>
                             <option value="3">Nasgor Srafood Fresh</option>
                             <option value="4">Nasgor Kambing Asli</option>
                           </select>
                        </td>
                     </tr>
                     <tr>
                         <th>Jumlah Pesanan</th>
                         <td>:</td>
                         <td>
                         <input type="number" name="nama" id="nama">
                         </td>
                     </tr>
                    <tr>
                            <td colspan="3" align="center">
                                <input type="submit" value="Submit">
                            </td>
                    </tr>
                </table>
    </form>
    </center>
</body>
</html>
    </section>




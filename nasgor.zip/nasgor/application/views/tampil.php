<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Cetak Pemesanan</title>
</head>
<body >
    <center>
<div class="card text-center" style="width: 21rem; height:50vh; background-color:#2f4f4f;">
  <div class="card-body text-light">
    <h5 class="card-title" style="font-weight: 600;">Total Pesanan Anda</h5>
    <h6 class="card-subtitle mb-2  mt-3">Atas Nama : Risqi japana</h6>
    <h6 class="card-subtitle mb-2 ">Menu yang dipesan : Nasgor Kambing Asli</h6>
    <h6 class="card-subtitle mb-2 ">Jumlah : 2</h6>
    <h6 class="card-subtitle mb-2 ">Total Harga : 60.000</h6>
    <p class="card-text mt-5">Silahkan datang ke kasir untuk membayar</p>
    <p class="card-text">Terimakasih Selamat Menikmati</p>
    
  </div>
</div>
    </center>
</body>
</html>